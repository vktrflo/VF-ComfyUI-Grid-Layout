import { findCell, splitCell, gridCell, resizeDivider, addBottomRow, KEY } from './layout.js';

const STYLE = `
.clt-overlay{position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:20;font:13px Consolas,monospace;color:var(--fg-color,#e4e4e7)}
.clt-plane{position:absolute;inset:0;transform-origin:0 0;pointer-events:none}
.clt-frame,.clt-cell{position:absolute;box-sizing:border-box;pointer-events:none;border:1px solid #5d7e89;border-radius:5px}
.clt-frame{border:2px solid #7197a5}
.clt-frame-header{position:absolute;left:0;right:0;top:0;height:34px;background:var(--comfy-menu-bg,#20282c);display:flex;align-items:center;gap:8px;padding:0 8px;pointer-events:auto;cursor:move;border-radius:3px 3px 0 0;user-select:none}
.clt-label{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;letter-spacing:.03em}
.clt-cell-header{height:25px;display:flex;align-items:center;padding:0 6px;background:var(--comfy-menu-bg,#20282c);pointer-events:auto;user-select:none;gap:6px;border-radius:4px 4px 0 0}
.clt-button{font:inherit;color:inherit;background:transparent;border:1px solid transparent;border-radius:3px;cursor:pointer;padding:2px 6px}
.clt-button:hover,.clt-button:focus-visible{background:#345361;border-color:#7197a5;outline:none}
.clt-hint{position:absolute;top:48px;left:12px;right:12px;color:#8ea1a9;font-size:12px;text-align:center;pointer-events:none}
.clt-cell.clt-target{border:2px solid #70d8be;box-shadow:inset 0 0 0 2px #70d8be33}
.clt-divider{position:absolute;pointer-events:auto;touch-action:none}
.clt-divider::after{content:'';position:absolute;background:#7197a5;opacity:.5;border-radius:2px}
.clt-divider-x{cursor:col-resize}.clt-divider-x::after{width:2px;height:32px;left:5px;top:calc(50% - 16px)}
.clt-divider-y{cursor:row-resize}.clt-divider-y::after{height:2px;width:32px;top:5px;left:calc(50% - 16px)}
.clt-divider:hover::after{opacity:1;background:#70d8be}
.clt-resize{position:absolute;right:0;bottom:0;width:18px;height:18px;pointer-events:auto;cursor:nwse-resize;touch-action:none;z-index:3;background:linear-gradient(135deg,transparent 55%,#7197a5 56%,#7197a5 64%,transparent 65%)}
.clt-resize-x,.clt-resize-y{position:absolute;pointer-events:auto;touch-action:none;z-index:2}
.clt-resize-x{right:-2px;top:36px;bottom:18px;width:10px;cursor:ew-resize}
.clt-resize-y{bottom:-2px;left:12px;right:18px;height:10px;cursor:ns-resize}
.clt-resize-x:hover,.clt-resize-y:hover{background:#70d8be55}
.clt-menu{position:fixed;z-index:10000;min-width:180px;padding:5px;background:var(--comfy-menu-bg,#20282c);color:var(--fg-color,#eee);border:1px solid #7197a5;border-radius:5px;box-shadow:0 4px 16px #0006;font:13px Consolas,monospace}
.clt-menu button{display:block;width:100%;text-align:left;padding:8px;border:0;background:none;color:inherit;cursor:pointer}.clt-menu button:hover{background:#345361}
.clt-dialog{background:var(--comfy-menu-bg,#20282c);color:var(--fg-color,#eee);border:1px solid #7197a5;border-radius:6px;padding:20px;min-width:280px;font:14px Consolas,monospace}.clt-dialog::backdrop{background:#0007}
.clt-dialog h3{margin:0 0 16px}.clt-dialog label{display:flex;justify-content:space-between;align-items:center;gap:18px;margin:12px 0}.clt-dialog input{background:var(--comfy-input-bg,#111b20);color:inherit;padding:6px;border:1px solid #5d7e89;border-radius:3px;max-width:200px}.clt-dialog footer{display:flex;justify-content:flex-end;gap:8px;margin-top:18px}.clt-dialog button{padding:6px 12px;color:inherit;background:#345361;border:1px solid #7197a5;border-radius:3px;cursor:pointer}
`;

function element(tag, className, text) {
  const el = document.createElement(tag);
  el.className = className;
  if (text != null) el.textContent = text;
  return el;
}
function rectStyle(el, rect) {
  Object.assign(el.style, { left: `${rect[0]}px`, top: `${rect[1]}px`, width: `${rect[2]}px`, height: `${rect[3]}px` });
}
function button(label, action, text = label) {
  const el = element('button', 'clt-button', text);
  el.type = 'button'; el.title = label; el.setAttribute('aria-label', label);
  el.addEventListener('pointerdown', e => e.stopPropagation());
  el.addEventListener('click', e => { e.stopPropagation(); action(e); });
  return el;
}

export class LayoutOverlay {
  constructor(controller) {
    this.controller = controller;
    this.app = controller.app;
    this.abort = new AbortController();
    const style = element('style', ''); style.textContent = STYLE; document.head.append(style); this.style = style;
    this.root = element('div', 'clt-overlay');
    this.plane = element('div', 'clt-plane'); this.root.append(this.plane);
    const container = this.app.canvas.canvas.parentElement;
    if (getComputedStyle(container).position === 'static') container.style.position = 'relative';
    container.append(this.root);
    this.menu = null; this.drag = null; this.nativeDrag = null; this.hover = null;
    const options = { capture: true, signal: this.abort.signal };
    document.addEventListener('pointerdown', e => this.nativeDown(e), options);
    document.addEventListener('pointermove', e => this.move(e), options);
    document.addEventListener('pointerup', e => this.up(e), options);
    document.addEventListener('pointercancel', e => this.up(e, true), options);
    window.addEventListener('blur', () => this.up(null, true), { signal: this.abort.signal });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { this.closeMenu(); this.up(null, true); } }, { signal: this.abort.signal });
    this.tick = this.tick.bind(this); this.animation = requestAnimationFrame(this.tick);
  }
  safe(action) {
    try { return action(); } catch (error) { this.message(error.message); }
  }
  message(text) {
    this.dialog('Layout Templates', [], () => {}, text);
  }
  dialog(title, fields, submit, message = '') {
    const dialog = element('dialog', 'clt-dialog');
    const form = document.createElement('form'); form.method = 'dialog';
    form.append(element('h3', '', title));
    if (message) form.append(element('p', '', message));
    const inputs = {};
    for (const field of fields) {
      const label = element('label', '', field.label), input = document.createElement('input');
      input.name = field.name; input.type = field.type ?? 'text'; input.value = field.value;
      input.setAttribute('aria-label', field.label); input.required = true;
      if (input.type === 'number') { input.min = '1'; input.max = '16'; input.step = '1'; } else input.maxLength = 120;
      label.append(input); form.append(label); inputs[field.name] = input;
    }
    const footer = element('footer', '');
    const cancel = element('button', '', fields.length ? 'Cancel' : 'Close'); cancel.type = 'button'; cancel.onclick = () => dialog.close();
    footer.append(cancel);
    if (fields.length) { const save = element('button', '', 'Apply'); save.type = 'submit'; footer.append(save); }
    form.append(footer); dialog.append(form); document.body.append(dialog);
    form.addEventListener('submit', e => {
      e.preventDefault();
      const values = Object.fromEntries(Object.entries(inputs).map(([key, input]) => [key, input.type === 'number' ? Number(input.value) : input.value]));
      dialog.close(); this.safe(() => submit(values));
    });
    dialog.addEventListener('close', () => dialog.remove(), { once: true });
    dialog.showModal();
  }
  closeMenu() { this.menu?.remove(); this.menu = null; }
  showMenu(event, actions) {
    this.closeMenu();
    const menu = element('div', 'clt-menu'); menu.setAttribute('role', 'menu');
    for (const [label, action] of actions) {
      const item = element('button', '', label); item.type = 'button'; item.setAttribute('role', 'menuitem');
      item.onclick = () => { this.closeMenu(); this.safe(action); }; menu.append(item);
    }
    document.body.append(menu);
    menu.style.left = `${Math.min(event.clientX, innerWidth - menu.offsetWidth - 8)}px`;
    menu.style.top = `${Math.min(event.clientY, innerHeight - menu.offsetHeight - 8)}px`;
    this.menu = menu; menu.firstElementChild.focus();
  }
  cellMenu(event, frameId, cellId) {
    const edit = action => this.controller.edit(() => {
      const frame = this.controller.frames.find(f => f.id === frameId);
      const cell = frame && findCell(frame.root, cellId);
      if (!cell) throw new Error('This cell is no longer available.');
      action(frame, cell);
    });
    this.showMenu(event, [
      ['Split into left / right', () => edit(frame => splitCell(frame, cellId, 'x'))],
      ['Split into top / bottom', () => edit(frame => splitCell(frame, cellId, 'y'))],
      ['Create grid…', () => this.dialog('Create cell grid', [{ name: 'rows', label: 'Rows', type: 'number', value: 2 }, { name: 'columns', label: 'Columns', type: 'number', value: 2 }], ({ rows, columns }) => edit(frame => gridCell(frame, cellId, rows, columns)))],
      ['Rename cell…', () => this.dialog('Rename cell', [{ name: 'label', label: 'Cell name', value: findCell(this.controller.frames.find(f => f.id === frameId).root, cellId).label }], ({ label }) => edit((frame, cell) => { cell.label = label; }))],
    ]);
  }
  frameMenu(event, frame) {
    frame = this.controller.frames.find(f => f.id === frame.id);
    if (!frame) return;
    this.showMenu(event, [
      ['Add bottom row', () => this.controller.edit(() => addBottomRow(this.controller.frames.find(f => f.id === frame.id)))],
      ['Rename layout…', () => this.dialog('Rename layout', [{ name: 'label', label: 'Layout name', value: frame.label }], ({ label }) => this.controller.edit(() => { frame.label = label; }))],
      ['Export empty template', () => {
        const blob = new Blob([JSON.stringify(this.controller.export(frame), null, 2)], { type: 'application/json' });
        const link = document.createElement('a'); link.href = URL.createObjectURL(blob);
        link.download = `${frame.label.replace(/[^a-z0-9_-]/gi, '-') || 'layout'}.layout.json`; link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 1000);
      }],
      ['Remove layout (keep nodes)', () => this.controller.remove(frame.id)],
    ]);
  }
  importAt(pos) {
    const input = document.createElement('input'); input.type = 'file'; input.accept = '.json,application/json';
    input.onchange = async () => {
      const file = input.files?.[0]; if (!file) return;
      if (file.size > 1024 * 1024) return this.message('Layout templates must be smaller than 1 MB.');
      try { this.controller.import(JSON.parse(await file.text()), pos); }
      catch (error) { this.message(error.message); }
    };
    input.click();
  }
  startDrag(event, kind, data) {
    if (event.button !== 0) return;
    event.preventDefault(); event.stopPropagation(); this.closeMenu();
    this.safe(() => {
      const frame = this.controller.frames.find(f => f.id === data.frame.id);
      if (!frame) return;
      data.frame = frame;
      if (kind === 'move') data.pos = [...frame.pos];
      if (kind.startsWith('resize')) data.size = [...frame.size];
      if (kind === 'divider') {
        data.cell = findCell(frame.root, data.cell.id);
        data.weights = [...data.cell.ratios];
      }
      this.controller.begin();
      this.drag = { kind, ...data, start: this.controller.adapter.point(event), graph: this.controller.graph, pointerId: event.pointerId };
    });
  }
  nativeDown(event) {
    if (this.menu && !this.menu.contains(event.target)) this.closeMenu();
    if (event.button !== 0 || this.drag || event.target.closest?.('.clt-overlay,.clt-menu,.clt-dialog,input,textarea,button,select,[contenteditable="true"]')) return;
    const container = this.app.canvas.canvas.parentElement;
    if (!container.contains(event.target) || this.app.configuringGraph) return;
    // Start before the native renderer moves anything. Its nested history
    // events are then grouped with our drop/reflow into the same undo step.
    this.safe(() => {
      if (!this.controller.frames.length) return;
      this.controller.begin();
      this.nativeDrag = { before: this.controller.snapshot(), graph: this.controller.graph, pointerId: event.pointerId };
    });
  }
  move(event) {
    if (this.drag && event.pointerId === this.drag.pointerId) {
      event.preventDefault(); event.stopPropagation();
      if (this.drag.graph !== this.controller.graph) return this.up(null, true);
      const point = this.controller.adapter.point(event), dx = point[0] - this.drag.start[0], dy = point[1] - this.drag.start[1];
      this.safe(() => {
        try {
          this.controller.edit(() => {
            const { frame, kind } = this.drag;
            if (kind === 'move') frame.pos = [this.drag.pos[0] + dx, this.drag.pos[1] + dy];
            else if (kind.startsWith('resize')) frame.size = [Math.max(200, this.drag.size[0] + (kind === 'resize-y' ? 0 : dx)), Math.max(150, this.drag.size[1] + (kind === 'resize-x' ? 0 : dy))];
            else {
              const { cell, index, weights, available } = this.drag;
              const delta = (cell.axis === 'x' ? dx : dy) / available;
              cell.ratios = [...weights]; resizeDivider(cell, index, delta);
            }
          });
        } catch (error) {
          this.drag = null; this.controller.end(); this.signature = null;
          throw error;
        }
      });
    } else if (this.nativeDrag) {
      this.hover = this.controller.target(this.controller.adapter.point(event))?.cell.id ?? null;
    }
  }
  up(event, cancelled = false) {
    if (this.drag && (!event || event.pointerId === this.drag.pointerId)) {
      this.drag = null; this.controller.end(); this.signature = null;
    }
    if (this.nativeDrag && (!event || event.pointerId === this.nativeDrag.pointerId)) {
      const pending = this.nativeDrag;
      if (pending.finishing) return;
      pending.finishing = true; this.hover = null;
      // Wait for the renderer's pointer-up handler to finish final snapping.
      requestAnimationFrame(() => {
        this.safe(() => {
          if (!cancelled && pending.graph === this.controller.graph) this.controller.finishNativeDrag(pending.before);
        });
        this.nativeDrag = null; this.controller.end(); this.signature = null;
      });
    }
  }
  tick() {
    if (!this.root.isConnected) return;
    if (!this.app.configuringGraph) {
      try {
        const layouts = this.controller.geometry();
        const { ds } = this.app.canvas;
        const signature = JSON.stringify([this.controller.graph?.id, layouts, ds.scale, [...ds.offset], this.hover]);
        const data = this.controller.graph?.extra?.[KEY];
        if (signature !== this.signature || data !== this.renderedData) {
          // Content can grow asynchronously (previews, conditional widgets,
          // Nodes 2.0 DOM measurement). Keep the attached stack coherent.
          if (!this.drag && !this.nativeDrag && this.controller.frames.length) this.controller.reflow();
          this.signature = signature; this.renderedData = data; this.render(layouts);
        }
        this.plane.style.transform = `translate(${ds.offset[0] * ds.scale}px,${ds.offset[1] * ds.scale}px) scale(${ds.scale})`;
      } catch (error) {
        if (!this.reportedError) { console.error('[Layout Templates]', error); this.reportedError = true; }
      }
    }
    this.animation = requestAnimationFrame(this.tick);
  }
  render(layouts) {
    const fragment = document.createDocumentFragment();
    for (const layout of layouts) {
      const { frame } = layout;
      const el = element('section', 'clt-frame'); el.dataset.frameId = frame.id; el.setAttribute('aria-label', frame.label);
      rectStyle(el, [...frame.pos, ...frame.size]);
      const header = element('div', 'clt-frame-header');
      header.append(element('span', 'clt-label', frame.label));
      header.append(button('Layout options', e => this.frameMenu(e, frame), '•••'));
      header.onpointerdown = e => this.startDrag(e, 'move', { frame, pos: [...frame.pos] });
      el.append(header);
      for (const axis of ['x', 'y']) {
        const edge = element('div', `clt-resize-${axis}`);
        edge.title = axis === 'x' ? 'Drag to resize rightmost cells' : 'Drag to resize bottom cells';
        edge.setAttribute('aria-label', axis === 'x' ? 'Resize layout width' : 'Resize layout height');
        edge.onpointerdown = e => this.startDrag(e, `resize-${axis}`, { frame });
        el.append(edge);
      }
      el.append(element('div', 'clt-resize'));
      el.lastElementChild.setAttribute('aria-label', 'Resize layout');
      el.lastElementChild.onpointerdown = e => this.startDrag(e, 'resize', { frame, size: [...frame.size] });
      fragment.append(el);
      for (const { cell, rect } of layout.cells) {
        const cellEl = element('div', `clt-cell${this.hover === cell.id ? ' clt-target' : ''}`);
        cellEl.dataset.cellId = cell.id; rectStyle(cellEl, rect);
        const cellHeader = element('div', 'clt-cell-header');
        cellHeader.append(element('span', 'clt-label', cell.label));
        cellHeader.append(button('Cell options', e => this.cellMenu(e, frame.id, cell.id), '+'));
        cellEl.append(cellHeader);
        if (!cell.nodes.length) cellEl.append(element('div', 'clt-hint', 'Drop nodes here'));
        fragment.append(cellEl);
      }
      for (const divider of layout.dividers) {
        const el = element('div', `clt-divider clt-divider-${divider.cell.axis}`); rectStyle(el, divider.rect);
        el.title = 'Drag to resize cells'; el.setAttribute('aria-label', 'Resize cell divider');
        el.onpointerdown = e => this.startDrag(e, 'divider', { frame, cell: divider.cell, index: divider.index, weights: [...divider.cell.ratios], available: divider.available });
        fragment.append(el);
      }
    }
    this.plane.replaceChildren(fragment);
  }
  dispose() {
    this.up(null, true); this.abort.abort(); cancelAnimationFrame(this.animation);
    this.closeMenu(); this.root.remove(); this.style.remove();
  }
}
